請先安裝 Python 相關套件:
    pip install -r requirements.txt

執行測試:
    pytest tests/ --log-cli-level=INFO